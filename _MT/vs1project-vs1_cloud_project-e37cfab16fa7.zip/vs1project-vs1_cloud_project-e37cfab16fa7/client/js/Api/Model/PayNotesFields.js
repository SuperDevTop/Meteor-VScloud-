export default class PayNotesFields {
    constructor({
        EmployeeID,
        ID,
        Notes,
        CreatedAt,
        UserID,
        UserName,
    }){
        this.EmployeeID = EmployeeID;
        this.ID = ID;
        this.Notes = Notes;
        this.CreatedAt = CreatedAt;
        this.UserID = UserID;
        this.UserName = UserName;
    }
}
  
  